from django.db import models

# Create your models here.
class share:
    name:str
    desc:str
