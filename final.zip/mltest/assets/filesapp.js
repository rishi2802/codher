$(document).ready(function () {
    $('input[type=submit]').click(function () {
      $('input[type=submit]').toggleClass('red');
    });
  });