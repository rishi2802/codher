var questionnaire = [
  {points:"0011",  statement:"I prefer to do things with others rather than on my own." },
  {points:"1100",  statement:"I prefer to do things the same way over and over again." },
  {points:"0011",  statement:"If I try to imagine something, I find it very easy to create a picture in my mind." },
  {points:"1100",  statement:"I frequently get so strongly absorbed in one thing that I lose sight of other things." },
  {points:"1100",  statement:"I often notice small sounds when others do not." },
  {points:"1100",  statement:"I usually notice car number plates or similar strings of information." },
  {points:"1100",  statement:"Other people frequently tell me that what I’ve said is impolite, even though I think it is polite." },
  {points:"0011",  statement:"When I’m reading a story, I can easily imagine what the characters might look like." },
  {points:"1100",  statement:"I am fascinated by dates." },
  {points:"0011",  statement:"In a social group, I can easily keep track of several different people’s conversations." },
  
],
  cols = [
      // &nbsp,
      // &nbsp,
      "Definitely agree",
      "Slightly agree",
      "Neutral",
      "Slightly disagree",
      "Definitely disagree"
    ];
var message = { 
  alert :`<p id="alert" class="btn btn-warning warning hidden"><i class="glyphicon glyphicon-time"></i> Important : you must select a preference in each of the 50 choices provided.</p>` ,
  result : `<div id="result" class="btn btn-success success hidden"><i class="glyphicon glyphicon-time"></i> Your score is <span></span>/50. See the legend below.</div>`,
  legend: `<div id="legend" class="hidden">
<ul>
<li>0-11 low result – indicating no tendency at all towards <a title="Asperger Traits" href="http://aspergerstest.net/asperger-behavior-impacts-everyday-life/">autistic traits</a>.</li>
<li>11-21 is the average result that people get (many women average around 15 and men around 17)</li>
<li>22-25 shows autistic tendencies slightly above the population average</li>
<li>26-31 gives a borderline indication of being on the autism spectrum. It is also possible to have aspergers or mild autism within this range.</li>
<li>32-50 indicates a strong likelihood of <a title="Aspergers or Autism Checklist" href="http://aspergerstest.net/aspergers-checklist/">Asperger syndrome</a> or autism.</li>
</ul></div>`,
  disclaimer: `<h3 id="disclaimer">Disclaimer</h3>
<p class="">
It is important to note, while backed by academic researches (Simon Baron-Cohen et al, 2001), this test stays a 5 minutes, conveniency test. A proper diagnostic requires hours of professional assessment. Also, people's psychology evolves along life, days, mood, and no test can gather the rich scope of someone's personality. Yet, we hope you enjoy this test as it enlight your social tendencies and raise awareness about mild autism :)</p>
`};


$("#hook").append(`<table id='table'></table>`);
$("#table").prepend(`
<thead>
<tr class="">
<td class="thead blank">&nbsp;</td>
<td class="thead blank">&nbsp;</td>
<th class="thead cell">`+cols[0]+`</th>
<th class="thead cell">`+cols[1]+`</th>
<th class="thead cell">`+cols[3]+`</th>
<th class="thead cell">`+cols[4]+`</th>
</tr>
</thead>
`);


for (var i=0; i<questionnaire.length; i++){
  var q = questionnaire[i],
      p = q.points,
      j=i;
  j.toString().length==1?j="0"+(i+1):j=i+1;
  var html = `<tr><td class="col q"> Q`+j
  +`</td><td>`+ q.statement
  +`</td><td class="cell"><input type="radio" name="s`+j+`" value="`+p[0]+`" required="">`
  +`</td><td class="cell"><input type="radio" name="s`+j+`" value="`+p[1]+`" required="">`
  +`</td><td class="cell"><input type="radio" name="s`+j+`" value="`+p[2]+`" required="">`
  +`</td><td class="cell"><input type="radio" name="s`+j+`" value="`+p[3]+`" required="">`
  +`</td></tr>`;
  $("#table").append(html)
}

$( "#hook" ).append(`<button id="button">Score</button>`);

$(".cell").click(function (){ this.getElementsByTagName('input')[0].checked=true;})

$("#hook").append(`<div id="message"></div>`);
$("#message").append(message.alert );
$("#message").append(message.result);
$("#message").append(message.legend+`<br>`+message.disclaimer);

$("#button").click(function () {
  var checked = $('input:radio:checked'),
      score = 0;
  if (checked.length != 10) {
    $("#alert").removeClass("hidden");
    $("#result").addClass("hidden");
    $("#legend").addClass("hidden");
  }else { 
    $("#alert").removeClass("hidden").addClass("hidden");
    $("#result").removeClass("hidden");
    $("#legend").removeClass("hidden");
  }

  for (var i=0; i< checked.length;i++){ score = score + +checked[i].value; }
  console.log(score+"/50");
  $("#result > span").text(score);
  document.getElementById("score").value = score;
});

